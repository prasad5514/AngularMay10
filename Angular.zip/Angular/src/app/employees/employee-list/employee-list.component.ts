import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/shared/employee.service';
import { EmployeeC } from 'src/app/shared/employee.modelFi'
import { ToastrService } from 'ngx-toastr';
declare var M: any;

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private service: EmployeeService,
    private toastr: ToastrService) { }
    list3:EmployeeC[];
    list:EmployeeC;

  ngOnInit() {
    this.service.refreshList();
    // this.service.refreshList().subscribe((data3)=>{
    //   this.list3=JSON.parse(JSON.stringify(data3))
    // })
  }

  populateForm(emp: EmployeeC) {
    this.service.formData2 = Object.assign({}, emp); 
    this.list=JSON.parse(JSON.stringify(this.service.formData2))

    //console.log(this.service.formData2)
    //alert(this.service.formData2.email);
    //this.toastr.warning(this.list.userName);
    // M.toast({ html: 'Deleted successfully', classes: 'rounded' });
    M.toast({ html: '<ol><li>'+this.list.userName+'</li><li>'+this.list.email+'</li><li>'+this.list.phone+'</li><li>'+this.list.gender+'</li><li>'+this.list.age+'</li></ol>', classes: 'rounded' });
    //alert("<h1>hello</h1>")
    //EmpModV=this.service.formData2;
    // if (confirm(this.service.formData2.email)){
    //   alert("hello")
    // }
  }

  onDelete(id: number) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteEmployee(id).subscribe(res => {
        this.service.refreshList();
        this.toastr.warning('Deleted successfully', 'EMP1. Register');
      });
    }
  }

}
